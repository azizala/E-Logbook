## E-Logbook menggunakan Codeigniter 3
E-Logbook berfungsi sebagai mengukur kinerja pegawai dengan laporan kegiatan sehari-hari, saat ini memang sudah tersedia absen berupa finger print, sehingga pegawai bisa datang ke kantor tepat waktu. Namun tak jarang absen pun bisa dipermainkan dengan datang lebih awal untuk sekedar absen lalu keluar dan kembali tidak pada waktunya

## Tampilan Web
![alt tag](https://github.com/hafiizh10/e_logbook/blob/master/assets/images/view.jpg)<br>
![alt tag](https://github.com/hafiizh10/e_logbook/blob/master/assets/images/view2.jpg)<br>
![alt tag](https://github.com/hafiizh10/e_logbook/blob/master/assets/images/view3.jpg)

## Web ini dibuat menggunakan
- Framework Codeigniter 3
- <a href="https://github.com/puikinsh/CoolAdmin">Template Cool Admin</a>
- Bootstrap 4.1
- PHP 7.4

## Catatan
Jika terjadi error jangan lupa cek file .htaccess nya ada modifikasi sedikit
- Admin<br>
Username : zoelva<br>
Password : 100500
