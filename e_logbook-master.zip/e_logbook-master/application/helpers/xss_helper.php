<?php

function cetak($str)
{
    echo htmlentities($str, ENT_QUOTES, 'utf-8');
}
